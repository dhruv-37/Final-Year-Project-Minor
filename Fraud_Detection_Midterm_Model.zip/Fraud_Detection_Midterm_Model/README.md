# Explainable accounting-fraud detection (mid-term version)

Extends Bao, Ke, Li, Yu and Zhang (2020), *Detecting Accounting Fraud in Publicly Traded U.S. Firms
Using a Machine Learning Approach*, Journal of Accounting Research 58(1).

This folder holds the code, the data, and the finished outputs of a full run, so the results can be
shown without running anything. It contains:

* the base paper's RUSBoost on 28 raw items, rebuilt in Python (the baseline);
* 133 scale-free features (ratios, Beneish M-score parts, Altman Z, growth gaps, within-year ranks);
* an ensemble of balanced-bagged LightGBM, balanced-bagged XGBoost and logistic regression,
  rank-averaged within each fiscal year;
* the same evaluation as the base paper: expanding window, 2-year gap, serial-fraud masking;
* review-budget metrics, a calibrated fraud probability, a case-clustered bootstrap and SHAP explanations;
* a scorer for new firms, with the trained model already saved.

## Start here

* `results/midterm_summary.txt`: every number on the slides, on one page.
* `results/log.txt`: the full log of the run that produced these results (48 minutes on a laptop CPU).
* `presentation/`: the mid-term slides (PowerPoint and PDF).
* `HOW_TO_RUN.txt`: commands to install, demo the saved model, or rerun everything.

## Results (test years 2003-2012, mean of yearly metrics, seed 42)

| Model | AUC | NDCG@5% | Sens@5% | Prec@1% |
|---|---|---|---|---|
| Baseline: RUSBoost, raw 28 items | 0.705 | 0.066 | 9.8% | 1.8% |
| RUSBoost, our 133 features | 0.732 | 0.071 | 12.7% | 1.6% |
| LightGBM, balanced bags | 0.730 | 0.074 | 14.2% | 1.9% |
| XGBoost, balanced bags | 0.726 | 0.072 | 14.2% | 1.6% |
| Logistic regression | 0.725 | 0.079 | 15.6% | 1.4% |
| **Proposed: LightGBM + XGBoost + LR** | **0.735** | **0.082** | **15.6%** | **1.7%** |

Gain of the proposed ensemble over the baseline (paired bootstrap, 1,000 resamples, clustered by AAER case and firm):
AUC +0.031 (95% CI +0.011 to +0.049), Sens@5% +0.058 (+0.015 to +0.096); NDCG@5% +0.015 is not significant.
2013 and 2014 are scored but left out of the averages because they have fewer than 15 frauds.

## Data

`data/data_FraudDetection_JAR2020.csv` is the base paper's public file (github.com/JarFraud/FraudDetection):
146,045 firm-years from 1990 to 2014, 964 of them fraud. The model uses 1991-2014 (141,463 firm-years,
949 frauds); the 1990 rows only supply prior-year values for growth features.

## Files

| Path | What it is |
|---|---|
| `run_pipeline.py` | The whole pipeline: features, tuning, ensemble choice, test years, metrics, calibration, deployable model, SHAP |
| `score_new_data.py` | Scores new firm-years with the saved model |
| `scripts/smoke_score.py` | End-to-end check of the scorer on 20 firms |
| `src/features.py` | Feature engineering and the winsoriser |
| `src/models.py` | RUSBoost, balanced bagging, logistic regression, rolling-origin CV, random search, rank averaging |
| `src/evaluate.py` | Yearly metrics, review-budget metrics, clustered bootstrap |
| `src/explain.py` | SHAP explanations of the deployed members |
| `tuning_cache/` | Feature-set, tuning and ensemble choices of the full run, for `--reuse` |
| `results/` | Outputs of the full run (listed in `HOW_TO_RUN.txt`) |
| `presentation/` | Mid-term slides |
