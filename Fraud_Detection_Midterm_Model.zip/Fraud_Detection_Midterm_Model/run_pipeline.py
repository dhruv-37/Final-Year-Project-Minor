"""End-to-end pipeline: explainable accounting-fraud detection (extends Bao et al., JAR 2020).

Mid-term version: LightGBM + XGBoost + logistic regression on 133 scale-free features.

    python run_pipeline.py                         # full run: test years 2003-2014
    python run_pipeline.py --reuse tuning_cache    # skip steps 2-4, reuse the saved tuning results
    python run_pipeline.py --fast                  # quick check: test years 2003-2008, fewer trials

Protocol = the authors' own, so numbers are directly comparable:
    * for each test year T in 2003..2014: train on fiscal years 1991..T-2 (2-year gap), test on T
    * serial-fraud rule: training rows from an AAER case that is also in the test year -> label 0
    * metrics are computed per test year and averaged (AUC, NDCG@k, sensitivity@k)
    * hyper-parameters are tuned ONLY on pre-2003 data with rolling-origin CV (no test peeking)
    * the Winsorizer is refit on the training rows of every CV fold / test year / final window
    * years with < --min_frauds frauds are listed but left out of period means and bootstraps
    * the deployable model is trained on 1991..--final_train_end (recent AAERs are not revealed yet)
"""
import argparse
import json
import os
import sys
import time

import joblib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.isotonic import IsotonicRegression
from sklearn.metrics import precision_recall_curve, roc_auc_score, roc_curve

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'src'))
from evaluate import (BOOT_METRICS, bootstrap_period, decision_metrics, period_mean,  # noqa: E402
                      per_year_metrics, rank_norm)
from explain import explain_all  # noqa: E402
from features import Winsorizer, engineer  # noqa: E402
from models import (BalancedBagger, LogReg, RUSBoost, cv_predict, ensemble_scores, lgbm_factory,  # noqa: E402
                    make_folds, mask_serial, random_search, sample_lgbm, sample_xgb, xgb_factory)

ap = argparse.ArgumentParser()
ap.add_argument('--data', default='data/data_FraudDetection_JAR2020.csv')
ap.add_argument('--out', default='results')
ap.add_argument('--fast', action='store_true')
ap.add_argument('--seed', type=int, default=42)
ap.add_argument('--n_jobs', type=int, default=-1)
ap.add_argument('--reuse', default='', help='dir with feature_set_selection / tuning_* / ensemble_selection csv: skip steps 2-4')
ap.add_argument('--final_train_end', type=int, default=2010,
                help='last fiscal year of the deployable model (label delay: later AAERs not yet revealed)')
ap.add_argument('--min_frauds', type=int, default=15,
                help='test years with fewer frauds are excluded from period means / bootstraps')
ap.add_argument('--n_boot', type=int, default=1000)
args = ap.parse_args()

os.chdir(os.path.dirname(os.path.abspath(__file__)))
os.makedirs(args.out, exist_ok=True)
T0 = time.time()
LOG = open(os.path.join(args.out, 'log.txt'), 'w')


def log(*a):
    msg = ' '.join(str(x) for x in a)
    print(msg, flush=True)
    LOG.write(msg + '\n')
    LOG.flush()


N_TRIALS = 8 if args.fast else 20
N_BAGS_TUNE = 3
N_BAGS_EVAL = 5 if args.fast else 10
TEST_YEARS = list(range(2003, 2009 if args.fast else 2015))
BASE = 'Baseline: RUSBoost (paper, raw 28)'
RUSE = 'RUSBoost (enhanced)'
LGBM = 'LightGBM bagged (enhanced)'
XGB = 'XGBoost bagged (enhanced)'
LR = 'Logistic regression (enhanced)'
PROP = 'PROPOSED: ensemble'
MODEL_NAMES = [BASE, RUSE, LGBM, XGB, LR, PROP]
E = args.final_train_end

# ----------------------------------------------------------------------------- data
log('[1/7] loading + feature engineering')
raw = pd.read_csv(args.data)
df, groups = engineer(raw)
df = df[df['fyear'] >= 1991].reset_index(drop=True)
years, y, PAAER = df['fyear'].values, df['misstate'].values, df['p_aaer'].values
GVKEY = df['gvkey'].values
POS_KEY = np.where(np.isnan(PAAER), -GVKEY, PAAER)            # bootstrap cluster: AAER case, else firm
pre_test = np.where((years >= 1991) & (years <= 2001))[0]     # data used for tuning
log(f'   rows={len(df):,}  frauds={y.sum()}  pre-test rows={len(pre_test):,} '
    f'(frauds {y[pre_test].sum()})  test years={TEST_YEARS[0]}-{TEST_YEARS[-1]}')

CANDIDATES = ['enhanced', 'rank_only', 'enhanced_rank']       # scale-free sets for the proposed model
WCOLS = groups['raw28'] + groups['enhanced_rank']
DW = df[WCOLS].astype(np.float32)


def winsorize(fit_rows):
    """Winsorizer fit on one training window only, applied to all rows."""
    wz = Winsorizer().fit(DW.iloc[fit_rows])
    return wz, wz.transform(DW)


folds = make_folds(years)
FOLD_D = [winsorize(tr)[1] for tr, _ in folds]


def fmat(cols):
    """Per-fold feature matrices, each winsorised on its own fold's training rows."""
    return [d[cols].values for d in FOLD_D]


def pick_fs(fs_df):
    c = fs_df[fs_df.feature_set.isin(CANDIDATES)]
    assert len(c), f'no scale-free candidate {CANDIDATES} in feature_set_selection.csv'
    return c.sort_values('cv_auc', ascending=False, kind='stable').iloc[0]['feature_set']


def pick_combo(combo_auc):
    """The baseline model (RUSraw) must not be a member of the proposed ensemble; among candidates
    within 0.002 CV-AUC of the best, prefer the simplest (fewest members), then the higher AUC."""
    cand = {k: v for k, v in combo_auc.items() if '+' in k and 'RUSraw' not in k}
    top = max(cand.values())
    return sorted([k for k, v in cand.items() if v >= top - 0.002], key=lambda k: (len(k.split('+')), -cand[k]))[0]


DEFAULT_L = dict(n_estimators=250, learning_rate=0.03, num_leaves=8, min_child_samples=30,
                 colsample_bytree=0.7, subsample=0.8, reg_lambda=3.0, ratio=10)


def build_lgbm(p, n_bags):
    return BalancedBagger(lgbm_factory(p, args.n_jobs), n_bags=n_bags, ratio=p['ratio'], seed=args.seed)


def build_xgb(p, n_bags):   # seed + 1: XGB bags draw different non-fraud samples than LGBM bags
    return BalancedBagger(xgb_factory(p, args.n_jobs), n_bags=n_bags, ratio=p['ratio'], seed=args.seed + 1)


def build_member(m, n_bags):
    if m == 'LGBM':
        return build_lgbm(bestL, n_bags)
    if m == 'XGB':
        return build_xgb(bestX, n_bags)
    if m == 'LR':
        return LogReg()
    return RUSBoost(seed=args.seed)


if args.reuse:
    def _best(fn):
        h = pd.read_csv(os.path.join(args.reuse, fn)).sort_values('cv_auc', ascending=False, kind='stable')
        h = h.iloc[0].to_dict()
        h.pop('cv_auc')
        return {k: (int(v) if k in ('n_estimators', 'num_leaves', 'min_child_samples', 'max_depth', 'ratio') else float(v))
                for k, v in h.items()}
    fs_df = pd.read_csv(os.path.join(args.reuse, 'feature_set_selection.csv'))
    best_fs = pick_fs(fs_df)
    FEATS = groups[best_fs]
    bestL, bestX = _best('tuning_lgbm.csv'), _best('tuning_xgb.csv')
    es = pd.read_csv(os.path.join(args.reuse, 'ensemble_selection.csv'))
    combo_auc = dict(zip(es.combo, es.cv_auc.astype(float)))
    best_combo = pick_combo(combo_auc)
    ENS_MEMBERS = best_combo.split('+')
    log(f'[reuse {args.reuse}] feature set={best_fs}, ensemble={best_combo}\n   lgbm={bestL}\n   xgb={bestX}')
else:
    # ----------------------------------------------------------------------------- feature set
    log('[2/7] choosing feature set by validation AUC (default LightGBM, rolling-origin CV)')
    fs_rows = []
    for name in ['raw28'] + CANDIDATES:                         # raw28 = reference only, never chosen
        _, auc = cv_predict(lambda a, b, c: build_lgbm(DEFAULT_L, N_BAGS_TUNE).fit(a, b).predict_proba(c),
                            fmat(groups[name]), y, folds, PAAER)
        fs_rows.append({'feature_set': name, 'n_features': len(groups[name]), 'cv_auc': auc})
        log(f'   {name:<13} n={len(groups[name]):>3}  cv AUC={auc:.4f}')
    fs_df = pd.DataFrame(fs_rows)
    fs_df.to_csv(os.path.join(args.out, 'feature_set_selection.csv'), index=False)
    best_fs = pick_fs(fs_df)
    FEATS = groups[best_fs]
    X_cv, Xraw_cv = fmat(FEATS), fmat(groups['raw28'])
    log(f'   -> using feature set: {best_fs} ({len(FEATS)} features)')

    # ----------------------------------------------------------------------------- tuning
    log('[3/7] tuning LightGBM (rolling-origin CV, serial-fraud masking)')
    bestL, aucL, histL = random_search(sample_lgbm, build_lgbm, X_cv, y, folds, N_TRIALS,
                                       seed=args.seed, n_bags=N_BAGS_TUNE, paaer=PAAER, log=log)
    histL.to_csv(os.path.join(args.out, 'tuning_lgbm.csv'), index=False)
    log('[3/7] tuning XGBoost')
    bestX, aucX, histX = random_search(sample_xgb, build_xgb, X_cv, y, folds, N_TRIALS,
                                       seed=args.seed + 1, n_bags=N_BAGS_TUNE, paaer=PAAER, log=log)
    histX.to_csv(os.path.join(args.out, 'tuning_xgb.csv'), index=False)

    # ----------------------------------------------------------------------------- ensemble choice
    log('[4/7] choosing ensemble recipe on validation folds')
    cv = {
        'LGBM': cv_predict(lambda a, b, c: build_lgbm(bestL, N_BAGS_TUNE).fit(a, b).predict_proba(c),
                           X_cv, y, folds, PAAER),
        'XGB': cv_predict(lambda a, b, c: build_xgb(bestX, N_BAGS_TUNE).fit(a, b).predict_proba(c),
                          X_cv, y, folds, PAAER),
        'LR': cv_predict(lambda a, b, c: LogReg().fit(a, b).predict_proba(c), X_cv, y, folds, PAAER),
        'RUSenh': cv_predict(lambda a, b, c: RUSBoost(seed=args.seed).fit(a, b).predict_proba(c),
                             X_cv, y, folds, PAAER),
        'RUSraw': cv_predict(lambda a, b, c: RUSBoost(seed=args.seed).fit(a, b).predict_proba(c),
                             Xraw_cv, y, folds, PAAER),
    }
    combo_auc = {k: v[1] for k, v in cv.items()}
    for k, a in combo_auc.items():
        log(f'   single model {k:<7} cv AUC={a:.4f}')
    combos = ['LGBM+XGB', 'LGBM+XGB+LR', 'LGBM+XGB+RUSenh', 'LGBM+XGB+RUSraw',
              'LGBM+XGB+LR+RUSenh', 'LGBM+XGB+LR+RUSenh+RUSraw']
    for c in combos:
        mem = c.split('+')
        aucs = [roc_auc_score(y[cv['LGBM'][0][k][0]],
                              ensemble_scores([cv[m][0][k][1] for m in mem])) for k in range(len(folds))]
        combo_auc[c] = float(np.mean(aucs))
        log(f'   ensemble {c:<28} cv AUC={combo_auc[c]:.4f}')
    best_combo = pick_combo(combo_auc)
    log(f'   -> ensemble = {best_combo}')
    pd.DataFrame([{'combo': k, 'cv_auc': v} for k, v in combo_auc.items()]).to_csv(
        os.path.join(args.out, 'ensemble_selection.csv'), index=False)
    ENS_MEMBERS = best_combo.split('+')

# ----------------------------------------------------------------------------- expanding-window test
log(f'[5/7] expanding-window evaluation, test years {TEST_YEARS[0]}-{TEST_YEARS[-1]}')
store = {m: [] for m in MODEL_NAMES}
te_rows = []
for yt in TEST_YEARS:
    t0 = time.time()
    tr = np.where((years >= 1991) & (years <= yt - 2))[0]
    te = np.where(years == yt)[0]
    ytr = mask_serial(y, PAAER, tr, te)
    _, D = winsorize(tr)
    X_all, X_raw = D[FEATS].values, D[groups['raw28']].values
    p = {}
    p[BASE] = RUSBoost(seed=args.seed).fit(X_raw[tr], ytr).predict_proba(X_raw[te])
    p[RUSE] = RUSBoost(seed=args.seed).fit(X_all[tr], ytr).predict_proba(X_all[te])
    p[LGBM] = build_lgbm(bestL, N_BAGS_EVAL).fit(X_all[tr], ytr).predict_proba(X_all[te])
    p[XGB] = build_xgb(bestX, N_BAGS_EVAL).fit(X_all[tr], ytr).predict_proba(X_all[te])
    p[LR] = LogReg().fit(X_all[tr], ytr).predict_proba(X_all[te])
    key = {'LGBM': LGBM, 'XGB': XGB, 'LR': LR, 'RUSenh': RUSE, 'RUSraw': BASE}
    p[PROP] = ensemble_scores([p[key[m]] for m in ENS_MEMBERS])
    for m in MODEL_NAMES:
        store[m].append(p[m])
    te_rows.append(te)
    a_b, a_p = roc_auc_score(y[te], p[BASE]), roc_auc_score(y[te], p[PROP])
    log(f'   test {yt}: train rows={len(tr):,} (frauds {ytr.sum()})  test frauds={y[te].sum():>3}  '
        f'AUC baseline={a_b:.3f}  proposed={a_p:.3f}  [{time.time() - t0:.0f}s]')

te_all = np.concatenate(te_rows)
yt_all, yrs_all = y[te_all], years[te_all]
PRED = {m: np.concatenate(store[m]) for m in MODEL_NAMES}
out = df.loc[te_all, ['gvkey', 'fyear', 'misstate']].copy()
for m in MODEL_NAMES:
    out[m] = PRED[m]
out.to_csv(os.path.join(args.out, 'test_predictions.csv'), index=False)

# ----------------------------------------------------------------------------- results
log('[6/7] results')
periods = [(2003, 2008)] + ([] if args.fast else [(2003, 2014)])
yearly = {m: per_year_metrics(yt_all, PRED[m], yrs_all) for m in MODEL_NAMES}
pd.concat({m: d for m, d in yearly.items()}, names=['model']).reset_index(level=0).to_csv(
    os.path.join(args.out, 'yearly_metrics.csv'), index=False)
dm = pd.concat({m: decision_metrics(yt_all, PRED[m], yrs_all) for m in MODEL_NAMES},
               names=['model']).reset_index(level=0)
dm.to_csv(os.path.join(args.out, 'decision_metrics.csv'), index=False)
dm.loc[dm.k == '1%', ['model', 'year', 'n', 'frauds', 'investigated', 'TP', 'FP', 'FN', 'TN']].to_csv(
    os.path.join(args.out, 'confusion_top1pct.csv'), index=False)

n_fr = pd.Series(yt_all).groupby(yrs_all).sum()
excluded = [int(t) for t in TEST_YEARS if n_fr.get(t, 0) < max(1, args.min_frauds)]
log(f'   years with < {args.min_frauds} frauds, listed in yearly_metrics.csv but excluded from period '
    f'means and bootstraps: {excluded or "none"}')

summary = {'feature_set': best_fs, 'n_features': len(FEATS), 'ensemble': best_combo, 'best_lgbm': bestL, 'best_xgb': bestX,
           'cv_auc': {k: float(v) for k, v in combo_auc.items()}, 'final_train_end': E,
           'min_frauds': args.min_frauds, 'excluded_years': excluded, 'n_boot': args.n_boot, 'periods': {}}
for lo, hi in periods:
    use = [t for t in range(lo, hi + 1) if t in TEST_YEARS and t not in excluded]
    boot = bootstrap_period(yt_all, PRED, yrs_all, POS_KEY[te_all], GVKEY[te_all], use,
                            n_boot=args.n_boot, seed=args.seed)
    means = {m: period_mean(yearly[m], lo, hi, args.min_frauds) for m in MODEL_NAMES}
    rows = []
    for m in MODEL_NAMES:
        r = {'model': m, **means[m].to_dict(),
             'AUC_CI95': f"[{np.percentile(boot[m][:, 0], 2.5):.3f}, {np.percentile(boot[m][:, 0], 97.5):.3f}]"}
        for j, met in enumerate(BOOT_METRICS):
            d = boot[m][:, j] - boot[BASE][:, j]
            r[f'{met}_gain'] = means[m][met] - means[BASE][met]          # point estimate
            r[f'{met}_gain_CI95'] = f"[{np.percentile(d, 2.5):+.3f}, {np.percentile(d, 97.5):+.3f}]"
            r[f'P({met}_gain<=0)'] = float((d <= 0).mean())
        rows.append(r)
    tab = pd.DataFrame(rows)
    tab.to_csv(os.path.join(args.out, f'test_metrics_{lo}_{hi}.csv'), index=False)
    log(f'\n=== test years {lo}-{hi} (mean of yearly metrics over {use}) ===')
    log(tab.round(4).to_string(index=False))
    summary['periods'][f'{lo}-{hi}'] = {'years_used': use, **tab.set_index('model').to_dict('index')}

# calibration: proposed out-of-sample scores (years <= final_train_end) -> fraud probability
cal = yrs_all <= E
assert cal.any(), f'no test years <= --final_train_end {E} to calibrate on'
iso = IsotonicRegression(out_of_bounds='clip', y_min=0, y_max=1).fit(PRED[PROP][cal], yt_all[cal])
cdf = pd.DataFrame({'score': PRED[PROP][cal], 'fraud_probability': iso.predict(PRED[PROP][cal]),
                    'fraud': yt_all[cal]})
cdf['bin'] = pd.qcut(cdf['score'], 10, labels=False, duplicates='drop')
calib = cdf.groupby('bin').agg(mean_score=('score', 'mean'), mean_fraud_probability=('fraud_probability', 'mean'),
                               observed_fraud_rate=('fraud', 'mean'), n=('fraud', 'size')).reset_index()
calib.to_csv(os.path.join(args.out, 'calibration.csv'), index=False)
cal_years = sorted({int(t) for t in yrs_all[cal]})
log(f'\n   isotonic calibration fit on proposed test-year scores {cal_years[0]}-{cal_years[-1]}:')
log(calib.round(4).to_string(index=False))
summary['calibration_years'] = cal_years
json.dump(summary, open(os.path.join(args.out, 'summary.json'), 'w'), indent=2, default=float)

# figures: yearly AUC lines + pooled ROC/PR
fig, ax = plt.subplots(1, 3, figsize=(16, 4.6))
for m in MODEL_NAMES:
    ax[0].plot(yearly[m]['year'], yearly[m]['AUC'], marker='o', ms=3,
               lw=2.6 if m == PROP else (2.0 if m == BASE else 0.9), ls='--' if m == BASE else '-', label=m)
ax[0].set(xlabel='Test year', ylabel='AUC', title='AUC by test year')
ax[0].legend(fontsize=6.5)
msk = yrs_all <= 2008
for m in MODEL_NAMES:
    fpr, tpr, _ = roc_curve(yt_all[msk], PRED[m][msk])
    ax[1].plot(fpr, tpr, lw=2.4 if m == PROP else 1.0)
    pr, rc, _ = precision_recall_curve(yt_all[msk], PRED[m][msk])
    ax[2].plot(rc, pr, lw=2.4 if m == PROP else 1.0)
ax[1].plot([0, 1], [0, 1], 'k:', lw=0.8)
ax[1].set(xlabel='FPR', ylabel='TPR', title='ROC, pooled test 2003-2008')
ax[2].set(xlabel='Recall', ylabel='Precision', title='Precision-recall, pooled test 2003-2008')
plt.tight_layout()
plt.savefig(os.path.join(args.out, 'performance_curves.png'), dpi=150)
plt.close()

# ----------------------------------------------------------------------------- deployable model + SHAP
log(f'\n[7/7] deployable model: fiscal years 1991-{E} (label delay), ensemble members {ENS_MEMBERS}')
tr = np.where((years >= 1991) & (years <= E))[0]
wz, D = winsorize(tr)
X_all = D[FEATS].values
mem = {m: build_member(m, 10).fit(X_all[tr], y[tr]) for m in ENS_MEMBERS}
joblib.dump({'features': FEATS, 'winsorizer': wz, 'winsor_cols': WCOLS, 'ensemble_members': ENS_MEMBERS,
             'models': mem, 'calibrator': iso, 'train_years': [1991, E]},
            os.path.join(args.out, 'final_models.joblib'), compress=3)

ex_years = list(range(E + 2, TEST_YEARS[-1] + 1))
note = ''
if not ex_years:
    ex_years, note = list(range(2003, 2009)), ' (no test year after the training window: in-sample for this model)'
log(f'   SHAP on the deployed members, explained on fiscal years {ex_years[0]}-{ex_years[-1]}{note}')
ex = np.where(np.isin(years, ex_years))[0]
X_ex = X_all[ex]
raw_ex = {m: mem[m].predict_proba(X_ex) for m in ENS_MEMBERS}
pct = np.zeros(len(ex))
for t in ex_years:                     # same recipe as scoring: rank each member within the fiscal year
    k = years[ex] == t
    pct[k] = ensemble_scores([s[k] for s in raw_ex.values()])
scores = pd.DataFrame({'risk_percentile': pct, 'risk_score': iso.predict(pct)})
imp = explain_all(mem, pd.DataFrame(X_ex, columns=FEATS), y[ex],
                  df.loc[ex, ['gvkey', 'fyear']].reset_index(drop=True), scores,
                  os.path.join(args.out, 'explain'), seed=args.seed, log=log)
log('\n   Top-10 features by mean |SHAP| (LightGBM + XGBoost):')
log(imp.head(10)[['feature', 'mean_abs_shap', 'meaning']].to_string(index=False))

# ----------------------------------------------------------------------------- summary as on the slides
if not args.fast:
    lines = ['Mid-term summary: test years 2003-2012 (years with fewer than '
             f'{args.min_frauds} frauds excluded: {excluded}), mean of yearly metrics, seed {args.seed}', '']
    t = pd.read_csv(os.path.join(args.out, 'test_metrics_2003_2014.csv')).set_index('model')
    lines.append(f'{"model":<36}{"AUC":>8}{"NDCG@5%":>10}{"Sens@5%":>10}{"Prec@1%":>10}{"Lift@1%":>9}')
    for m in MODEL_NAMES:
        r = t.loc[m]
        lines.append(f'{m:<36}{r["AUC"]:>8.3f}{r["NDCG@5%"]:>10.3f}{100 * r["Sens@5%"]:>9.1f}%{100 * r["Prec@1%"]:>9.1f}%{r["Lift@1%"]:>9.1f}')
    lines += ['', f'Gain of {PROP} over the baseline (paired bootstrap, {args.n_boot} resamples, clustered by AAER case and firm):']
    for met in BOOT_METRICS:
        r = t.loc[PROP]
        lines.append(f'   {met:<8} {r[f"{met}_gain"]:+.3f}   95% CI {r[f"{met}_gain_CI95"]}   P(gain <= 0) = {r[f"P({met}_gain<=0)"]:.3f}')
    use = [y_ for y_ in range(2003, 2015) if y_ not in excluded]
    dsel = dm[dm.year.isin(use)].groupby(['model', 'k'])[['precision', 'recall', 'lift']].mean()
    lines += ['', 'Review budget (top k% of each year): precision / recall']
    for k in ('1%', '2%', '5%'):
        a, b = dsel.loc[(PROP, k)], dsel.loc[(BASE, k)]
        lines.append(f'   top {k}: proposed {100 * a.precision:.1f}% / {100 * a.recall:.1f}%    '
                     f'baseline {100 * b.precision:.1f}% / {100 * b.recall:.1f}%')
    lines += ['', 'AUC by test year (proposed vs baseline):']
    yp, yb = yearly[PROP].set_index('year'), yearly[BASE].set_index('year')
    for yr in use:
        lines.append(f'   {yr}: {yp.loc[yr, "AUC"]:.3f} vs {yb.loc[yr, "AUC"]:.3f}  ({int(yp.loc[yr, "frauds"])} frauds)')
    lines += ['', 'Top-10 SHAP drivers (mean |SHAP|, LightGBM + XGBoost, 2012-2014 sample):']
    for _, r in imp.head(10).iterrows():
        lines.append(f'   {r["feature"]:<14}{r["mean_abs_shap"]:.3f}  {r["meaning"]}')
    open(os.path.join(args.out, 'midterm_summary.txt'), 'w', encoding='utf-8').write('\n'.join(lines) + '\n')
    log('\n' + '\n'.join(lines))
log(f'\nDone in {(time.time() - T0) / 60:.1f} min. Outputs in {args.out}/')
